package com.emp.crud.DAO;

import com.emp.crud.DTO.EmployeeDTO;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.List;

public class EmployeeDAO {
    
    // Method to configure Hibernate and get SessionFactory
    private SessionFactory getSessionFactory() {
        Configuration cfg = new Configuration();
        cfg.configure();  // Load configuration from hibernate.cfg.xml
        cfg.addAnnotatedClass(EmployeeDTO.class);  // Add annotated class
        return cfg.buildSessionFactory();  // Build SessionFactory
    }

    public void saveEmployee(EmployeeDTO dto) {
        // 1. Open a new Session
        Session session = getSessionFactory().openSession();
        // 2. Begin transaction
        Transaction tx = session.beginTransaction();
        // 3. Save the EmployeeDTO object
        session.save(dto);
        // 4. Commit the transaction
        tx.commit();
        // 5. Close the session
        session.close();
    }

    public List<EmployeeDTO> getAllEmployees() {
        Session session = getSessionFactory().openSession();
        List<EmployeeDTO> employees = session.createQuery("from EmployeeDTO").list();
        session.close();
        return employees;
    }

    public void deleteEmployeeByDeptNo(int deptno) {
        Session session = getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.createQuery("delete from EmployeeDTO where deptno = :deptno")
               .setParameter("deptno", deptno)
               .executeUpdate();
        tx.commit();
        session.close();
    }

    public void updateEmployeeSalaryBySal(int oldSal, int newSal) {
        Session session = getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.createQuery("update EmployeeDTO set sal = :newSal where sal = :oldSal")
               .setParameter("newSal", newSal)
               .setParameter("oldSal", oldSal)
               .executeUpdate();
        tx.commit();
        session.close();
    }
}
