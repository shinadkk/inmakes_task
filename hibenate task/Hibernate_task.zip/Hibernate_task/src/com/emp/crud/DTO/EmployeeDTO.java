package com.emp.crud.DTO;

import java.io.Serializable;

import javax.persistence.*;
@Entity
@Table(name = "Employee_table")
public class EmployeeDTO implements Serializable {
	
	@Override
	public String toString() {
		return "EmployeeDTO [empno=" + empno + ", ename=" + ename + ", sal=" + sal + ", job=" + job + ", deptno="
				+ deptno + ", getEmpno()=" + getEmpno() + ", getEname()=" + getEname() + ", getSal()=" + getSal()
				+ ", getJob()=" + getJob() + ", getDeptno()=" + getDeptno() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	@Id
	@Column(name="Employee_number")
	 private long empno;
	@Column(name="Employee_name")
	 private String ename;
	@Column(name="Employee_salary")
	 private int sal;
	@Column(name="Employee_job")
	 private String job;
	@Column(name="Employee_deptno")
	 private int deptno ;
	
	
	public EmployeeDTO() {
		System.out.println("Employee DTO object created");
	}
	 
	 
	public long getEmpno() {
		return empno;
	}
	public void setEmpno(long empno) {
		this.empno = empno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	 
	 
	 
 
}
