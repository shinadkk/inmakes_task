package com.emp.crud.util;

import com.emp.crud.DAO.EmployeeDAO;
import com.emp.crud.DTO.EmployeeDTO;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        EmployeeDAO dao = new EmployeeDAO();

        // 1. Persisting the class to the database
        EmployeeDTO dto1 = new EmployeeDTO();
        dto1.setEmpno(1);
        dto1.setEname("Arun");
        dto1.setSal(10000);
        dto1.setJob("HR");
        dto1.setDeptno(1000);
        dao.saveEmployee(dto1);
        System.out.println("Insertion Success");

        // 2. Retrieving records from the database
        List<EmployeeDTO> employees = dao.getAllEmployees();
        System.out.println("Employee Records:");
        for (EmployeeDTO employee : employees) {
            System.out.println("Emp No: " + employee.getEmpno() + ", Name: " + employee.getEname() +
                               ", Salary: " + employee.getSal() + ", Job: " + employee.getJob() +
                               ", Dept No: " + employee.getDeptno());
        }

        // 3. Deleting record (condition: where deptno is 30)
        dao.deleteEmployeeByDeptNo(30);
        System.out.println("Records with deptno 30 deleted.");

        // 4. Updating record (Condition: Where sal is 8000, update sal to 11000)
        dao.updateEmployeeSalaryBySal(8000, 11000);
        System.out.println("Salary updated from 8000 to 11000.");
    }
}
