package com.relation.company.DTO;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "company")
public class CompanyDTO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int companyId;

    @Column(name = "company_name")
    private String companyName;

    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinTable(name = "company_product", 
               joinColumns = @JoinColumn(name = "company_id"), 
               inverseJoinColumns = @JoinColumn(name = "product_id"))
    private Set<ProductDTO> products = new HashSet<>();


    public int getCompanyId() {
        return companyId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Set<ProductDTO> getProducts() {
        return products;
    }

    public void setProducts(Set<ProductDTO> products) {
        this.products = products;
    }

    public void addProduct(ProductDTO product) {
        this.products.add(product);
        product.getCompanies().add(this);
    }

    public void removeProduct(ProductDTO product) {
        this.products.remove(product);
        product.getCompanies().remove(this);
    }
}
