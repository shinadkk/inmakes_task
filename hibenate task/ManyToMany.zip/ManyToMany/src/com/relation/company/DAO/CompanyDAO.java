package com.relation.company.DAO;

import com.relation.company.DTO.CompanyDTO;
import com.relation.company.DTO.ProductDTO;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CompanyDAO {

    private static final Session HibernateUtil = null;

    public void saveCompany(CompanyDTO company) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(company);
        tx.commit();
        session.close();
    }

    public void addProductToCompany(int companyId, ProductDTO product) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        
        CompanyDTO company = session.get(CompanyDTO.class, companyId);
        if (company != null) {
            company.addProduct(product);
            session.saveOrUpdate(company);
        }
        
        tx.commit();
        session.close();
    }

    public void removeProductFromCompany(int companyId, int productId) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        
        CompanyDTO company = session.get(CompanyDTO.class, companyId);
        ProductDTO product = session.get(ProductDTO.class, productId);
        
        if (company != null && product != null) {
            company.removeProduct(product);
            session.saveOrUpdate(company);
        }
        
        tx.commit();
        session.close();
    }
    
    public CompanyDTO getCompany(int companyId) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        CompanyDTO company = session.get(CompanyDTO.class, companyId);
        session.close();
        return company;
    }
}
