package com.relation.company.Util;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.relation.company.DTO.CompanyDTO;
import com.relation.company.DTO.ProductDTO;

import java.util.HashSet;
import java.util.Set;

public class Main {


	private static SessionFactory sessionFactory;

	private static SessionFactory buildSessionFactory() {
	    if (sessionFactory == null) {
	        try {
	            Configuration configuration = new Configuration();
	            configuration.configure(); // Load hibernate.cfg.xml
	            configuration.addAnnotatedClass(CompanyDTO.class);
	            configuration.addAnnotatedClass(ProductDTO.class);
	            sessionFactory = configuration.buildSessionFactory();
	        } catch (Throwable ex) {
	            System.err.println("Initial SessionFactory creation failed: " + ex);
	            throw new ExceptionInInitializerError(ex);
	        }
	    }
	    return sessionFactory;
	}
    
    

    public static void main(String[] args) {
        SessionFactory sessionFactory = buildSessionFactory();

        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        try {
            CompanyDTO company1 = new CompanyDTO();
            company1.setCompanyName("Tech Innovators");

            ProductDTO product1 = new ProductDTO();
            product1.setProductName("Smartphone");

            ProductDTO product2 = new ProductDTO();
            product2.setProductName("Laptop");

            Set<ProductDTO> products = new HashSet<>();
            products.add(product1);
            products.add(product2);
            company1.setProducts(products);

            session.save(company1);

            tx.commit();

            tx = session.beginTransaction();
            CompanyDTO savedCompany = session.get(CompanyDTO.class, company1.getCompanyId());
            System.out.println("Company: " + savedCompany.getCompanyName());
            savedCompany.getProducts().forEach(p -> System.out.println("Product: " + p.getProductName()));
            tx.commit();

        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
            sessionFactory.close();
        }
    }
}
